//
//  Rigi.h
//  Rigi
//
//  Created by Dimitri van Oijen on 03/05/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for Rigi.
FOUNDATION_EXPORT double RigiVersionNumber;

//! Project version string for Rigi.
FOUNDATION_EXPORT const unsigned char RigiVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Rigi/PublicHeader.h>


